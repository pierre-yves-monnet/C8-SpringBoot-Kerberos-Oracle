# Camunda 8 Management Identity with OracleDB and Kerberos

The `docker-compose.yaml` file will set up a Kerberos server (`kdc-kadmin`), an OracleDB `oracle-db`, 
a Keycloak (`keycloak`), a Postgres (`postgres`, only for Keycloak mind), and finally an Identity (`identity`) service.

The Kerberos server operates within the `EXAMPLE.COM` domain, so all principals will be scoped to that.

While a lot of this is just setting up Kerberos, Oracle, etc., the important parts for Identity are the
following:

You need to set several Java properties to make this configure Kerberos, and the Oracle JDBC driver to use Kerberos:

The following essentially set up the JAAS portion (Java Authentication and Authorization Service), by configuring it to use Kerberos. The `krb5.conf` and `jaas.conf` files are very important, as they tell the JDK how to authenticate to Kerberos, as well as how to find the keytab that will contain the passwordless authentication credentials.

```
javax.security.auth.useSubjectCredsOnly=false
java.security.krb5.conf=/tmp/krb5.conf
java.security.auth.login.config=/tmp/jaas.conf
```

The following configure the Oracle driver to use Kerberos (via JAAS). Note that `KerberosJaasLoginModule` has to match the section name in your `/tmp/jaas.conf` file, as this file can contain many different so called modules (or sections).

```
oracle.net.authentication_services=(KERBEROS5)
oracle.net.KerberosJaasLoginModule=Server
oracle.net.KerberosRealm=EXAMPLE.COM
oracle.net.kerberos5_mutual_authentication=true
```

An example `jaas.conf`, using a keytab at `/tmp/keytabs/camunda-identity-1.keytab` would look like:

```
Server {
        com.sun.security.auth.module.Krb5LoginModule required
        principal="krbtgt/EXAMPLE.COM@EXAMPLE.COM"
        useKeyTab=true
        keyTab="/tmp/keytabs/camunda-identity-1.keytab"
        doNotPrompt=true
        storeKey=true
        useTicketCache=false
        isInitiator=true;
};
```

After everything is setup, Identity will try to connect using the principal `krbtgt/EXAMPLE.COM@EXAMPLE.COM`. Note that this user doesn't exist in OracleDB unfortunately at that point, so you need to create it.

```sh
docker exec -it oracle-oracle-db-1 bash
```

Then login as a DBA:

```sh
bash-4.4$ sqlplus "sys/camunda@//localhost:1521/FREEPDB1 as sysdba"
```

Then create the new user and grant it all privileges (out of laziness):

```sh
SQL> CREATE USER krbtgt IDENTIFIED EXTERNALLY AS 'krbtgt/EXAMPLE.COM@EXAMPLE.COM';
SQL> GRANT ALL PRIVILEGES TO krbtgt;
```

## Troubleshooting

There are some debug settings which are very helpful when the authentication is failing. You can add `debug=true` in your `jaas.conf`, and you can also set `-Dsun.security.krb5.debug=true` when launching your JVM. Note that the useful log is at the beginning of the launch, and tons of logs are spit out after, so avoid tailing the logs.

Note that sometimes Java will say that it cannot find the key for a given principal. This can happen not just because the key doesn't exist, but it can happen if your keytab file is not readable! So make sure you set appropriate file permissions to it.

Also, this can happen if the encryption is wrong. By default, the community version of Java only supports 128 length keys, and Kerberos is configured for 256. So you need to configure your Kerberos to also emit 128 length keys, OR configure your JVM to allow 256 length keys. The error is not very helpful unfortunately, so good luck.
